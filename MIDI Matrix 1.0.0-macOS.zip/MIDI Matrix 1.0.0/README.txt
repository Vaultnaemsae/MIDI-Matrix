MIDI Matrix
Version 1.0.0

Install:
1. Unzip the download.
2. Move MIDI Matrix.app to your Applications folder.
3. Open MIDI Matrix.

Support: vaultnaemsae@icloud.com
